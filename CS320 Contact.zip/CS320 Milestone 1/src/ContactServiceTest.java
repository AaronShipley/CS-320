/**
 * CS 320 ContactServiceTest
 * Aaron Shipley
 */

import org.junit.jupiter.api.Test; // import JUNIT 5 test
import static org.junit.jupiter.api.Assertions.*; // import Assertions from JUNIT5

//declare class ContactServiceTest
public class ContactServiceTest {
	
	//Test to verify adding new contact
	@Test
	public void testAdd(){
		System.out.println("Add new contact");
		ContactService cs = new ContactService();
		Contact test1 = new Contact("4178985", "Dan", "Marino", "4252658698", "13 Dolphin Dr");
		assertEquals(true, cs.addContact(test1));
	}
	// Test to verify parameters of deleting contact
	@Test
	public void testDelete() {
		System.out.println("Deleted Contact");
		ContactService cs = new ContactService();

		Contact test1 = new Contact("4178985", "Dan", "Marino", "4252658698", "13 Dolphin Dr");
		Contact test2 = new Contact("2562781", "Steve", "Rinella", "8185651212", "MeatEater Wy");
		Contact test3 = new Contact("8675309", "Tommy", "Twotone", "1800546285", "Fisherman Ln");
		cs.addContact(test1);
		cs.addContact(test2);
		cs.addContact(test3);
		assertEquals(true, cs.deleteContact("2562781"));
		assertEquals(false, cs.deleteContact("2562782"));
		assertEquals(false, cs.deleteContact("2562781"));
	}
	// Test to verify parameters of updating contact
	@Test
	public void testUpdate(){
		System.out.println("Updated Contact");
		ContactService cs = new ContactService();

		Contact test1 = new Contact("4178985", "Dan", "Marino", "4252658698", "13 Dolphin Dr");
		Contact test2 = new Contact("2562781", "Steve", "Rinella", "8185651212", "MeatEater Wy");
		Contact test3 = new Contact("8675309", "Tommy", "Twotone", "1800546285", "Fisherman Ln");
		cs.addContact(test1);
		cs.addContact(test2);
		cs.addContact(test3);
		assertEquals(true, cs.updateContact("8675309", "TommyFirst", "TwotoneLast",
		"1800546285", "Fisherman Ln"));
		assertEquals(false, cs.updateContact("9852722", "TommyFirst", "TwotoneLast",
		"1800546285", "Fisherman Ln"));
	}


}
