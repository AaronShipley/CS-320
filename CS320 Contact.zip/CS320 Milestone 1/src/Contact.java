/**
 * CS 320 Contact
 * Aaron Shipley
 */
// declare public class for Contact
public class Contact {
	
	// Declare objects of type string 
	public static Object contactList;
	private String contactID;
	private String firstName;
	private String lastName;
	private String phoneNum;
	private String address;

	public Contact(String contactID, String firstName,String lastName,String Number, String Address) {
        this.contactID = contactID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = Address;
        this.phoneNum = Number;
    }

    
    public Contact(String contactID2) {
		// TODO Auto-generated constructor stub
	}

    // ContactID getter method
	public String getContactID() {
        return contactID;
    }
	// firstName getter method
    public String getFirstName() {
        return firstName;
    }
    //firstName setter
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
 // lastName getter method
    public String getLastName() {
        return lastName;
    }
    // lastName setter
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    //address getter method
    public String getAddress() {
        return address;
    }
    // address setter
    public void setAddress(String Address) {
        this.address = Address;
    }
    // phoneNum getter method
    public String getphoneNum() {
        return phoneNum;
    }
    // phoneNum setter
    public void setphoneNum(String Number) {
        this.phoneNum = Number;
    }
    ////validate parameters of contactID
     public boolean validateContactID(String contactID) {
        if (contactID != null && !contactID.isEmpty() && contactID.length() <= 10)
            return true;

        return false;
    }
   //validate parameters of firstName
    public boolean validatefirstName(String firstName) {
        if (firstName != null && !firstName.isEmpty() && firstName.length() <= 10)
            return true;

        return false;
    }
    //validate parameters of lastName
     public boolean validatelastName(String lastName) {
        if (lastName != null && !lastName.isEmpty()&& lastName.length() <= 10)
            return true;

        return false;
    }
     // validate phoneNum parameters
     public boolean validateNumber(String Number) {
        if (Number != null && !Number.isEmpty() && Number.length() <= 10)
            return true;

        return false;
    }
   //validate parameters of address
     public boolean validateAddress(String Address) {
        if (Address != null&& !Address.isEmpty() && Address.length() <= 30)
            return true;

        return false;
    }
	public static void main(String[] args)
	{

	}
	
}

