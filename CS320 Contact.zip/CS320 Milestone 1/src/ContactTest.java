/**
 * CS 320 ContactTest
 * Aaron Shipley
 */
// ipmort libraries from JUNIT5
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Declare class ContactTest
public class ContactTest {
    
    public ContactTest() {
    }
    // Run Before All processes
    @BeforeAll
    public static void setUpClass() {
    }
    //Run after all processes
    @AfterAll
    public static void tearDownClass() {
    }
    //run before each test
    @BeforeEach
    public void setUp() {
    }
    // run after each segment
    @AfterEach
    public void tearDown() {
    }

   // Test to validate getting contact information
    @Test
    public void testGetContactID() {
        System.out.println("getContactID");
        Contact instance = new Contact("1234","tim","home","loot","cart");
        String expResult = "1234";
        String result = instance.getContactID();
        assertEquals(result,expResult);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    // Test to validate firstName
    @Test
    public void testGetFirstName() {
        System.out.println("getFirstName");
        Contact instance = new Contact("2294","tim","home","loot","cart");
        String expResult = "tim";
        String result = instance.getFirstName();
        assertEquals(expResult, result);
        
        
    }

    // Test to validate setting firstName
    @Test
    public void testSetFirstName() {
        System.out.println("setFirstName");
        String firstName = "abc";
        Contact instance = new Contact("9782","tim","home","loot","cart");
        instance.setFirstName(firstName);
        assertEquals(firstName,instance.getFirstName());
        
        
    }

    //Test to validate getting lastName
    @Test
    public void testGetLastName() {
        System.out.println("getLastName");
        Contact instance = new Contact("2789","tim","home","loot","cart");
        String expResult = "home";
        String result = instance.getLastName();
        assertEquals(expResult, result);
        
        
    }

    // Test to validate setting lastName
    @Test
    public void testSetLastName() {
        System.out.println("setLastName");
        String lastName = "defg";
        Contact instance = new Contact("7463","tim","home","loot","cart");
        instance.setLastName(lastName);
        assertEquals(lastName,instance.getLastName());
        
        
    }

    //Test to validate address
    @Test
    public void testGetAddress() {
        System.out.println("getAddress");
        Contact instance = new Contact("9876","tim","home","loot","cart");
        String expResult = "cart";
        String result = instance.getAddress();
        assertEquals(expResult, result);
        
        
    }

    // Test to validate setting address
    @Test
    public void testSetAddress() {
        System.out.println("setAddress");
        String Address = "123a";
        Contact instance = new Contact("24243","tim","home","loot","cart");
        instance.setAddress(Address);
        assertEquals(Address,instance.getAddress());
        
        
    }

    // Test to validate getting phoneNum
    @Test
    public void testGetNumber() {
        System.out.println("getNumber");
        Contact instance = new Contact("5430","tim","home","loot","cart");
        String expResult = "loot";
        String result = instance.getphoneNum();
        assertEquals(expResult, result);
        
        
    }

    // Test to validate setting phoneNum
    @Test
    public void testSetNumber() {
        System.out.println("setNumber");
        String Number = "123423";
        Contact instance = new Contact("8956","tim","home","loot","cart");
        instance.setphoneNum(Number);
        assertEquals(Number,instance.getphoneNum());
        
        
    }

    //Test to validate contactID
    @Test
    public void testValidateID() {
        System.out.println("validateID");
        String contactID = "985621839914";
        Contact instance = new Contact("7728","tim","home","loot","cart");
        //System.out.println(instance.validateContactID(contactID));
        boolean result = instance.validateContactID(contactID);
        assertEquals(false, result);
        
        
    }

    
    @Test
    public void testValidatefirstName() {
        System.out.println("validatefirstName");
        String firstName = "";
        Contact instance = new Contact("4321","tim","home","loot","cart");
        boolean expResult = false;
        boolean result = instance.validatefirstName(firstName);
        assertEquals(expResult, result);
        
        
    }

    
    @Test
    public void testValidatelastName() {
        System.out.println("validatelastName");
        String lastName = "";
        Contact instance = new Contact("8888","tim","home","loot","cart");
        boolean expResult = false;
        boolean result = instance.validatelastName(lastName);
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testValidateNumber() {
    	Contact instance = new Contact("213","al","143","12345","lkuluk");
    	String number = "12345123";
    	assertEquals(true,instance.validateNumber(number));
    }

    
    @Test
    public void testValidateAddress() {
        System.out.println("validateAddress");
        String Address = "";
        Contact instance = new Contact("5555","tim","home","loot","cart");
        boolean result = instance.validateAddress(Address);
        assertEquals(false, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Contact.main(args);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
   
    @Test
    public void testValidateContactID() {
        System.out.println("validateContactID");
        String contactID = "";
        Contact instance = new Contact("7676","tim","home","loot","cart");
        boolean expResult = false;
        boolean result = instance.validateContactID(contactID);
        assertEquals(expResult, result);
        
    }
    
}



