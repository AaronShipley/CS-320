/**
 * CS 320 ContactService
 * Aaron Shipley
 */

import java.util.ArrayList;

// declare ContactService Class to contain contacts
public class ContactService {


	private ArrayList<Contact> contacts;

	public ContactService(){
		//call new array list for contact storage
		contacts = new ArrayList<>();
	}

	//boolean declared in order to add contact
	public boolean addContact(Contact contact){
		boolean contactAlready= false;
		//search through contact list
		for (Contact contactList:contacts){
			//if statement to see if contact exists in the list
			if (contactList.equals(contact)){
				contactAlready = true;
			}
		}
		// add contact to array list if doesnt exist
		if (!contactAlready){
			contacts.add(contact);
			//after adding is now true
			return true;
		}
		else {
			return false;
		}
	}
	
	//boolean to delete contact by its contact ID
	public boolean deleteContact(String contactID){
		//search through contact list
		for (Contact contactList:contacts){
			//if contactID found, it will delete entry and return
			if (contactList.getContactID().equals(contactID)){
				//remove and return true
				contacts.remove(contactList);
				return true;
			}
		}
		//else return false
		return false;
	}
	
	//update is trickiest due to needing to make sure still fits parameters
	//nothing means no change
	public boolean updateContact(String contactID, String firstName, String lastName,
	String phoneNumber, String address){
		//run through loop again
		for (Contact contactList:contacts){
			//if contactID matches, run through each also making sure it isnt "" 
			//all requirements were met
			//then return true as it did equal update.
			if (contactList.getContactID().equals(contactID)){
				if(!firstName.equals("") && !(firstName.length()>10)){
					//set firstName
					contactList.setFirstName(firstName);
				}
				//validate input equals and fits length parameter
				if(!lastName.equals("") && !(lastName.length()>10)){
					// set lastName
					contactList.setFirstName(lastName);
				}
				//validate input equals and fits length parameter
				if(!phoneNumber.equals("") && (phoneNumber.length()==10)){
					//set phoneNum
					contactList.setFirstName(phoneNumber);
				}
				//validate input equals and fits length parameter
				if(!address.equals("") && !(address.length()>30)){
					//set address
					contactList.setFirstName(address);
				}
				return true;
			}
		}
		//else return false
		return false;
	}


}